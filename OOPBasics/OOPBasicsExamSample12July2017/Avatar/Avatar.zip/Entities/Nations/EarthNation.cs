﻿public class EarthNation : Nation
{
}