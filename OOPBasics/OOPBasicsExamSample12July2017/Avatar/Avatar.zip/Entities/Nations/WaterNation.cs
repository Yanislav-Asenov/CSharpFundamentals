﻿public class WaterNation : Nation
{
}