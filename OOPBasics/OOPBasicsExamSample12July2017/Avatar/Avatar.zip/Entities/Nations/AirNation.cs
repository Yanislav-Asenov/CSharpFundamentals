﻿using System;
using System.Collections.Generic;

public class AirNation : Nation
{
}