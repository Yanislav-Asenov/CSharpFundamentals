﻿public class FireNation : Nation
{
}