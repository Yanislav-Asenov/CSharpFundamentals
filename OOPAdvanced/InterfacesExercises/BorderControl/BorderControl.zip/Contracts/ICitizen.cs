﻿public interface ICitizen : IIdentifiable, IPerson, IBirthable, IBuyer
{
}