﻿public interface IPet : IBirthable
{
    string Name { get; }
}