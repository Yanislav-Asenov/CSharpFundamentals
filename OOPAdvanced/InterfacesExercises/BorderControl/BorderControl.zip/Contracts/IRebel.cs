﻿public interface IRebel : IPerson, IBuyer
{
    string Group { get; }
}