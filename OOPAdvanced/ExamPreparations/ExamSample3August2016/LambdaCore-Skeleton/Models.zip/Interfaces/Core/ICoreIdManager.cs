﻿namespace LambdaCore_Skeleton.Interfaces.Core
{
    public interface ICoreIdManager
    {
        char GetNext();
    }
}
