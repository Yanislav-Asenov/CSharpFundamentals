﻿namespace LambdaCore_Skeleton.Interfaces.Core.Commands
{
    public interface ICommand
    {
        string Execute();
    }
}
