﻿namespace LambdaCore_Skeleton.Interfaces.Core
{
    public interface IRunnable
    {
        void Run();
    }
}
