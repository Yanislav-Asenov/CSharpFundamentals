﻿namespace LambdaCore_Skeleton.Interfaces.Core
{
    public interface IInterpreter
    {
        string InterpretCommand(string input);
    }
}
