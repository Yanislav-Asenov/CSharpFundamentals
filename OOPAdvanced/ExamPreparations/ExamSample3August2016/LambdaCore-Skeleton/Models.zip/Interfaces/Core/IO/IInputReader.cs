﻿namespace LambdaCore_Skeleton.Interfaces.Core.IO
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
