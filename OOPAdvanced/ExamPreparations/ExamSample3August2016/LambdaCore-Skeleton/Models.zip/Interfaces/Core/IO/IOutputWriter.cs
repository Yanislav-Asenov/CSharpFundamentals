﻿namespace LambdaCore_Skeleton.Interfaces.Core.IO
{
    public interface IOutputWriter
    {
        void WriteLine(string output);
    }
}
