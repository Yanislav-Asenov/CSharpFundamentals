﻿namespace LambdaCore_Skeleton.Interfaces.Core.IO
{
    public interface IInputOutputManager : IInputReader, IOutputWriter
    {

    }
}
