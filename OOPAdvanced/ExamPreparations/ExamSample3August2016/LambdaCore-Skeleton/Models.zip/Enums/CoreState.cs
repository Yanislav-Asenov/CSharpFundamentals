﻿namespace LambdaCore_Skeleton.Enums
{
    public enum CoreState
    {
        NORMAL,
        CRITICAL,
    }
}
