﻿namespace LambdaCore_Skeleton.Models.Cores
{
    public class SystemCore : BaseCore
    {
        public SystemCore(string id, string type, int durability) 
            : base(id, type, durability)
        {
        }
    }
}
