﻿public interface IGemFactory
{
    IGem CreateGem(string type, string clarity);
}