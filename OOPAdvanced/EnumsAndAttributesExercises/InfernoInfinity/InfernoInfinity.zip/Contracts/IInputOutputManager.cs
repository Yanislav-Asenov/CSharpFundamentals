﻿public interface IInputOutputManager : IReader, IWriter
{
}