﻿public enum GemClarity
{
    Chipped = 1,
    Regular = 3,
    Perfect = 5,
    Flawless = 10,
}