﻿namespace RecyclingStation.BusinessLogic.Interfaces.IO
{
    public interface IInputOutputManager : IReader, IWriter
    {
    }
}
