﻿namespace RecyclingStation.BusinessLogic.Interfaces.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
