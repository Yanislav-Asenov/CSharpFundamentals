﻿namespace RecyclingStation.BusinessLogic.Interfaces.Core
{
    public interface IRunnable
    {
        void Run();
    }
}
