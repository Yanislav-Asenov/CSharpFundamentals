﻿namespace RecyclingStation.Interfaces.Core
{
    public interface IRecyclingManager
    {

    }
}
